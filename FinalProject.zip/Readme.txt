              
                                                                                                PLANTY STORE
    
    Features:

    Browser : I used Chrome Browser.                                   
    Header and Footer : Used in All Webpages  and three Headers and one footer in Homepage.

    Slider : Used for displaying the images sliding in Homepage.

    MODAL POP-UP : Used in login,Signup,Categories(button) Sections.
                                            
    Categories : Two categories are used and each category has 6 items.
 
    Images : Used in sliders , Categories Section , about , icon.

    Cards Display : Used in two section of categories and  in About us page.

    Javascript: Used in Slider and for Validation of login,Signup,Contact Sections.





                                           


                                           
 


                                      
                                           